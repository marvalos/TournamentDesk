module.exports = {
	Book: require("./book"),
	User: require("./user")
  };
